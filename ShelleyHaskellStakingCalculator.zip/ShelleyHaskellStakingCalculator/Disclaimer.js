import React from 'react'
import Query from '../../queries/CalculatorPageQuery'
import styled from 'styled-components'
import Container from '@material-ui/core/Container'
import Markdown from '@input-output-hk/front-end-core-components/components/Markdown'

const DisclaimerWrap = styled.section`
  background: ${({ theme }) => theme.palette.grey[100]};
  padding: 6rem 0;
  
  * {
    font-size:95%;
  }
`
const Disclaimer = () => {
  return (
    <Query
      render={content => (
        <DisclaimerWrap>
          <Container maxWidth='lg'>
            <h4>{content.staking_calculator.disclaimer_heading}</h4>
            <Markdown source={content.staking_calculator.disclaimer} />
          </Container>
        </DisclaimerWrap>
      )}
    />
  )
}

export default Disclaimer
