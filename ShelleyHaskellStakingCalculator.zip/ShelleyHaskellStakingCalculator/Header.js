import React from 'react'
import Query from '../../queries/CalculatorPageQuery'
import styled from 'styled-components'
import Container from '@material-ui/core/Container'

const CalcHeader = styled.header`
  position:relative;
  overflow:hidden;
  padding: 8rem 0;
  background:#335cbe linear-gradient(180deg, rgba(0,51,173,1) 0%, rgba(51,92,190,1) 100%);
  * {
    color: ${({ theme }) => theme.palette.primary.contrastText};
  }
  p {
    max-width:80rem;
  }
  .ada-symbol {
    position:absolute;
    top:-45rem;
    right:15vw;
    opacity:0.07;
    font-size:75rem;
    padding:0;
    margin:0;
    transform: rotate(7deg);
    @media(max-width:799px) {
      right: 0;
    }
  }
`

const Header = () => {
  return (
    <Query
      render={content => (
        <CalcHeader>
          <Container maxWidth='lg'>
            <h1>{content.staking_calculator.page_heading}</h1>
            <p>{content.staking_calculator.page_sub_heading}</p>
          </Container>
          <p className='ada-symbol'>₳</p>
        </CalcHeader>
      )}
    />
  )
}

export default Header
